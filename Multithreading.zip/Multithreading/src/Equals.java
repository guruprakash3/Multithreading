public class Equals {  
    public static void main(String[] args) {  
        String s1 = "HCL Technologies";    
        String s2 = "HCL Technologies";    
        String s3 = "HCL Technologies";  
        System.out.println(s2.equals(s3));    
        if (s1.equals(s3)) {  
            System.out.println("both strings are equal");  
        }else System.out.println("both strings are unequal");     
    }  
}  