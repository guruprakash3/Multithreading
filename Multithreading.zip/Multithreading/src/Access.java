public class Access extends Thread     
{    
    public void run()  
    {  
        System.out.println(Thread.currentThread().getName()+" has completed the execution");  
    }  
    public static void main(String arg[]) throws InterruptedException, SecurityException    
    {   
        Access t1 = new Access();    
        Access t2 = new Access();    
        t1.start();  
        t2.start();  
          
        t1.checkAccess();    
        System.out.println(t1.getName() + " has access");    
        t2.checkAccess();    
        System.out.println(t2.getName() + " has access");    
    }    
}  