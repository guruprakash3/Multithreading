public class Run implements Runnable  
{    
    public void run()  
    {    
        System.out.println("program gets executing");    
    }    
    public static void main(String args[])  
    {    
        Run r1=new Run();    
        Thread t1 =new Thread(r1);    
        t1.start();    
    }    
}  