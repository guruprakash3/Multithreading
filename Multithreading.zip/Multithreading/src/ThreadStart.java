  class ThreadStart extends Thread{  
  
  public void run(){  
    System.out.println("Program is getting executed");  
  }
     
   public static void main(String args[]){  
     ThreadStart obj=new ThreadStart();   
     obj.start();  
  }  
}