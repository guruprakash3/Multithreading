public class HashCode {  
    public static void main(String[] args)  
    {  
        Integer i = new Integer("243");  
        int hashValue = i.hashCode();  
        System.out.println("Hash code Value for object is: " + hashValue);  
    }  
}  